# Sentinel Lite — Fraud Money-Trail Console

Synthetic-data prototype that follows the money trail across wallets to flag mule accounts. Pure Python engine, FastAPI backend, plain-JS dashboard (no CDN, works offline after install).

## Run
```
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn backend.main:app --port 8000
```
Open http://127.0.0.1:8000 (API docs at `/docs`).

## How scoring works
- **Graph /40** – time-respecting trace (30 min) from each wallet's largest inflow: fan-out, hop depth, cash-out reached.
- **Anomaly /40** – largest inflow vs the typical transfer size.
- **Rule /20** – 80%+ of the inflow passed on within 15 minutes.
- **Propagation** – wallets funded by a very high-risk hub get +10 graph points.
- HOLD ≥ 60, WATCH ≥ 35.

## Pages
Overview · Alert Queue (evidence, money-trail graph, analyst decision) · Customer Warning (English + Bangla) · Audit Log (SQLite).

## Deploy (Render)
`render.yaml` is included. Set `SENTINEL_DB` to a persistent path to keep the audit log.

## Limits
All data is synthetic. Scores are hand-weighted, not calibrated probabilities. No real transfers or holds happen. Analyst name is a text field, not authentication.
