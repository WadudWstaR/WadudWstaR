import os
import sqlite3
import time
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .data import generate
from .engine import analyse, summarise

ROOT = Path(__file__).resolve().parent.parent
DB = os.environ.get("SENTINEL_DB", str(ROOT / "sentinel.sqlite3"))
app = FastAPI(title="Sentinel Lite")
accts, tx, truth = generate()
cases = analyse(accts, tx)


def db():
    con = sqlite3.connect(DB)
    con.execute("CREATE TABLE IF NOT EXISTS audit(ts REAL, acct TEXT, analyst TEXT, outcome TEXT, note TEXT, score INT)")
    return con


class Decision(BaseModel):
    analyst: str = Field(min_length=1, max_length=60)
    outcome: Literal["HOLD", "RELEASE", "ESCALATE"]
    note: str = Field(default="", max_length=300)


class Warn(BaseModel):
    recipient: str = Field(max_length=10)
    amount: int = Field(gt=0, le=1_000_000)


def get(a):
    if a not in cases:
        raise HTTPException(404, "Unknown wallet")
    return cases[a]


@app.get("/api/summary")
def summary():
    return summarise(cases, truth)


@app.get("/api/alerts")
def alerts():
    rows = sorted((c for c in cases.values() if c["level"] != "LOW"), key=lambda c: -c["score"])
    return [{k: c[k] for k in ("id", "city", "score", "level", "cash", "delay")} for c in rows]


@app.get("/api/wallets")
def wallets():
    return sorted(cases)


@app.get("/api/alerts/{a}")
def alert(a: str):
    return get(a)


@app.post("/api/alerts/{a}/decision")
def decide(a: str, d: Decision):
    c = get(a)
    with db() as con:
        con.execute("INSERT INTO audit VALUES(?,?,?,?,?,?)", (time.time(), a, d.analyst, d.outcome, d.note, c["score"]))
    return {"ok": True}


@app.get("/api/audit")
def audit():
    with db() as con:
        rows = con.execute("SELECT ts,acct,analyst,outcome,note,score FROM audit ORDER BY ts DESC LIMIT 100").fetchall()
    return [dict(zip(("ts", "acct", "analyst", "outcome", "note", "score"), r)) for r in rows]


@app.post("/api/warn")
def warn(w: Warn):
    c = get(w.recipient)
    risky = c["level"] != "LOW"
    return {
        "risky": risky, "score": c["score"],
        "en": "Warning: this recipient shows suspicious activity. Verify who they are before sending." if risky else "No warning for this recipient.",
        "bn": "সতর্কতা: এই প্রাপকের অ্যাকাউন্টে সন্দেহজনক লেনদেন দেখা গেছে। টাকা পাঠানোর আগে প্রাপককে যাচাই করুন।" if risky else "এই প্রাপকের জন্য কোনো সতর্কতা নেই।",
    }


@app.get("/api/health")
def health():
    return {"status": "ok"}


app.mount("/", StaticFiles(directory=ROOT / "frontend", html=True), name="ui")
