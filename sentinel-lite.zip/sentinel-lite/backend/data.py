"""Synthetic wallet transactions: normal traffic + 3 scripted mule rings."""
import random
from datetime import datetime, timedelta


def generate(seed=7):
    r = random.Random(seed)
    t0 = datetime(2026, 1, 10, 9, 0)
    cities = ["Dhaka", "Chattogram", "Sylhet", "Rajshahi", "Khulna"]
    accts = {f"W{i:03d}": {"kind": "customer", "city": r.choice(cities)} for i in range(120)}
    accts.update({f"A{i:02d}": {"kind": "agent", "city": r.choice(cities)} for i in range(8)})
    customers = [a for a in accts if a[0] == "W"]
    agents = [a for a in accts if a[0] == "A"]
    tx = []

    def add(s, d, amt, t, typ="transfer"):
        tx.append({"src": s, "dst": d, "amount": int(amt), "ts": t.isoformat(timespec="seconds"), "type": typ})

    for _ in range(600):
        s, d = r.sample(customers, 2)
        add(s, d, r.lognormvariate(7, 0.7), t0 + timedelta(minutes=r.randint(0, 8640)))
    for _ in range(80):
        add(r.choice(customers), r.choice(agents), r.lognormvariate(7.2, 0.5), t0 + timedelta(minutes=r.randint(0, 8640)), "cashout")

    pool, truth = r.sample(customers, 18), set()
    for k in range(3):
        victim, hub, mules = pool[6 * k], pool[6 * k + 1], pool[6 * k + 2: 6 * k + 6]
        truth.update([hub, *mules])
        base = t0 + timedelta(days=r.randint(1, 5), hours=r.randint(0, 12))
        amt = r.randint(40000, 90000)
        add(victim, hub, amt, base)
        for i, m in enumerate(mules):
            add(hub, m, amt * 0.97 / 4, base + timedelta(minutes=2 + i))
            add(m, r.choice(agents), amt * 0.95 / 4, base + timedelta(minutes=6 + 2 * i), "cashout")
    tx.sort(key=lambda e: e["ts"])
    return accts, tx, truth
