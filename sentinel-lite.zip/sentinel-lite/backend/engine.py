"""Money-trail engine: time-respecting trace + anomaly + rule + risk propagation."""
import math
import statistics
from collections import defaultdict
from datetime import datetime

WINDOW = 1800  # seconds a trail is followed after the largest inflow


def _t(s):
    return datetime.fromisoformat(s)


def _level(score):
    return "HOLD" if score >= 60 else "WATCH" if score >= 35 else "LOW"


def analyse(accts, tx):
    inc, out = defaultdict(list), defaultdict(list)
    for e in tx:
        out[e["src"]].append(e)
        inc[e["dst"]].append(e)
    med = statistics.median(e["amount"] for e in tx)
    cases = {}
    for a, m in accts.items():
        if m["kind"] != "customer":
            continue
        c = dict(id=a, city=m["city"], graph=0, anomaly=0, rule=0, fan=0, depth=0, cash=0,
                 delay=0, inflow=0, src=None, evidence=[], nodes=[], edges=[])
        cases[a] = c
        ins = [e for e in inc[a] if e["type"] == "transfer"]
        if not ins:
            continue
        big = max(ins, key=lambda e: e["amount"])
        t0, c["inflow"], c["src"] = _t(big["ts"]), big["amount"], big["src"]
        level, edges, seen, last = {big["src"]: 0, a: 1}, [big], {a}, t0
        frontier = [(a, t0)]
        while frontier:
            nxt = []
            for node, tm in frontier:
                for e in out[node]:
                    te = _t(e["ts"])
                    if te < tm or (te - t0).total_seconds() > WINDOW:
                        continue
                    if e["type"] == "cashout":
                        c["cash"] += e["amount"]
                        last = max(last, te)
                    elif e["dst"] in seen:
                        continue
                    else:
                        seen.add(e["dst"])
                        nxt.append((e["dst"], te))
                    level.setdefault(e["dst"], level[node] + 1)
                    edges.append(e)
            frontier = nxt
        c["fan"], c["depth"] = len(seen) - 1, max(level.values()) - 1
        c["delay"] = int((last - t0).total_seconds())
        z = max(big["amount"] / med, 1)
        moved = sum(e["amount"] for e in edges[1:] if e["src"] == a)
        c["graph"] = round(min(40, 6 * c["fan"] + 4 * c["depth"] + 16 * min(1, c["cash"] / big["amount"])))
        c["anomaly"] = round(40 * min(1, math.log(z) / math.log(80)))
        c["rule"] = 20 if moved >= 0.8 * big["amount"] and c["delay"] <= 900 else 0
        c["nodes"] = [{"id": n, "level": l, "kind": accts[n]["kind"]} for n, l in level.items()]
        c["edges"] = [{"s": e["src"], "d": e["dst"], "amount": e["amount"], "type": e["type"]} for e in edges]
        ev = c["evidence"]
        ev.append(f"Largest inflow Tk {big['amount']:,} is {z:.0f}x the typical transfer")
        if c["fan"] >= 3:
            ev.append(f"Rapid fan-out to {c['fan']} accounts")
        if c["cash"]:
            ev.append(f"Tk {c['cash']:,} reached agent cash-out within {c['delay'] // 60} min")
        if c["rule"]:
            ev.append("Pass-through of 80%+ of the inflow within 15 minutes")
    first = {a: min(100, c["graph"] + c["anomaly"] + c["rule"]) for a, c in cases.items()}
    for a, c in cases.items():
        if c["src"] in first and first[c["src"]] >= 80:  # funded by a high-risk hub
            c["graph"] = min(40, c["graph"] + 10)
            c["evidence"].append(f"Funded by high-risk account {c['src']}")
        c["score"] = min(100, c["graph"] + c["anomaly"] + c["rule"])
        c["level"] = _level(c["score"])
    return cases


def summarise(cases, truth):
    flagged = {a for a, c in cases.items() if c["level"] != "LOW"}
    hit = flagged & truth
    return {
        "accounts": len(cases),
        "hold": sum(c["level"] == "HOLD" for c in cases.values()),
        "watch": sum(c["level"] == "WATCH" for c in cases.values()),
        "cash_exposed": sum(c["cash"] for c in cases.values() if c["level"] == "HOLD"),
        "precision": round(len(hit) / len(flagged), 2) if flagged else 0,
        "recall": round(len(hit) / len(truth), 2) if truth else 0,
    }
